# FitBuddy — AI Fitness Plan Generator

FitBuddy is a FastAPI web application for generating seven-day workout plans, nutrition/recovery tips, and feedback-based plan revisions. It stores user profiles and plans in SQLite and uses Google Gemini when `GOOGLE_API_KEY` is configured.

## Features

- Responsive HTML/CSS interface rendered with Jinja2.
- Personalized seven-day workout plans.
- Goal-specific nutrition/recovery tips.
- Feedback-based plan updates while preserving the original plan.
- SQLite persistence through SQLAlchemy.
- JSON API endpoints and interactive OpenAPI docs.
- HTTP Basic Authentication for the admin dashboard.
- Clearly labelled demo mode when no Gemini key is configured.
- Automated tests.

## Requirements

- Python 3.10 or newer (Python 3.11+ recommended).
- VS Code and its Python extension.
- A Gemini API key for live AI generation. The app also runs in demo mode without one.

## Setup on Windows (VS Code)

1. Extract the project ZIP and open the `fitbuddy` folder in VS Code.
2. Open **Terminal → New Terminal**.
3. Create a virtual environment:

   ```powershell
   py -m venv .venv
   ```

4. Activate it:

   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, use Command Prompt and run:

   ```bat
   .venv\Scripts\activate.bat
   ```

5. Install dependencies:

   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

6. Copy `.env.example` to `.env`. Add your Gemini key to `GOOGLE_API_KEY` to enable live AI generation. Without a key, FitBuddy runs in clearly marked demo mode.
7. Start the server from the project root:

   ```powershell
   uvicorn app.main:app --reload
   ```

8. Open:
   - Web app: http://127.0.0.1:8000
   - API docs: http://127.0.0.1:8000/docs
   - Health check: http://127.0.0.1:8000/health

Stop the server with `Ctrl+C`.

## Configure Gemini

Get a key from Google AI Studio: https://aistudio.google.com/app/apikey

Put it in `.env`:

```env
GOOGLE_API_KEY=your_actual_key_here
GEMINI_PLAN_MODEL=gemini-2.5-flash
GEMINI_TIP_MODEL=gemini-2.5-flash
```

Restart Uvicorn after changing `.env`. Model IDs are configurable because model availability can change. Never commit `.env` or share your API key.

## Admin dashboard

Open http://127.0.0.1:8000/view-all-users. The browser will request HTTP Basic credentials.

Set your credentials in `.env`:

```env
ADMIN_USERNAME=admin
ADMIN_PASSWORD=use-a-long-unique-password
```

Change the default password before using the app with real user data. The admin JSON endpoint is also protected by the same credentials.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| `GET` | `/health` | Health check |
| `POST` | `/api/plans` | Create or regenerate a user's plan |
| `POST` | `/api/plans/{user_id}/feedback` | Revise a plan with feedback |
| `GET` | `/api/nutrition-tip?goal=muscle_gain` | Get a nutrition/recovery tip |
| `GET` | `/api/admin/users` | List users and plans (admin auth required) |
| `DELETE` | `/api/admin/users/{user_id}` | Delete a user and their plan (admin auth required) |

HTML routes are `/`, `/generate-workout`, `/submit-feedback`, `/view-all-users`, and `/admin/delete-user`.

### Example API request

```bash
curl -X POST http://127.0.0.1:8000/api/plans \
  -H "Content-Type: application/json" \
  -d '{
    "username": "Sam",
    "user_id": "sam-001",
    "age": 22,
    "weight": 60,
    "goal": "muscle_gain",
    "intensity": "medium"
  }'
```

Valid goals: `weight_loss`, `muscle_gain`, `general_fitness`, `flexibility`, `endurance`.
Valid intensities: `low`, `medium`, `high`.

## Testing

With the virtual environment active, run:

```powershell
pytest -q
```

## Project structure

```text
fitbuddy/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── database.py
│   ├── models.py
│   ├── schemas.py
│   ├── ai_service.py
│   ├── routes.py
│   ├── templates/
│   │   ├── base.html
│   │   ├── index.html
│   │   ├── result.html
│   │   └── all_users.html
│   └── static/css/style.css
├── tests/test_app.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## Notes and limitations

- This is a learning/demo application, not medical advice. AI-generated exercise and nutrition suggestions can be inaccurate. Users should adapt activities to their abilities and consult a qualified professional when needed.
- Demo mode uses example content and does not claim that Gemini was called.
- Admin authentication is HTTP Basic and intended as a local-project safeguard. For public deployment, add HTTPS, stronger authentication, CSRF protection for browser forms, rate limiting, database backups, and production secret management.
- SQLite is created automatically at startup. Back up `fitbuddy.db` before deleting or moving it.
