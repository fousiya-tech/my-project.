import os
import tempfile

_TEST_DB = tempfile.NamedTemporaryFile(prefix="fitbuddy_test_", suffix=".db", delete=False)
_TEST_DB.close()
os.environ["DATABASE_URL"] = f"sqlite:///{_TEST_DB.name}"
os.environ.setdefault("GOOGLE_API_KEY", "")

from fastapi.testclient import TestClient
from app.main import app
from app.database import init_db
from app.ai_service import generate_nutrition_tip

init_db()
client = TestClient(app)


def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_home_page_renders():
    response = client.get("/")
    assert response.status_code == 200
    assert "Build your plan" in response.text


def test_api_generates_and_persists_demo_plan():
    response = client.post("/api/plans", json={
        "username": "Test User", "user_id": "test-user-001", "age": 22,
        "weight": 58.5, "goal": "general_fitness", "intensity": "low",
    })
    assert response.status_code == 200
    body = response.json()
    assert body["user_id"] == "test-user-001"
    assert "Day 1" in body["workout_plan"]
    assert body["mode"] in {"demo", "gemini"}


def test_feedback_requires_existing_user():
    response = client.post("/api/plans/not-found/feedback",
                           json={"feedback": "Please add more gentle cardio."})
    assert response.status_code == 404


def test_nutrition_tip_rejects_unknown_goal():
    response = client.get("/api/nutrition-tip?goal=not-a-goal")
    assert response.status_code == 422


def test_admin_endpoint_requires_credentials():
    response = client.get("/api/admin/users")
    assert response.status_code == 401


def test_nutrition_tip_returns_content():
    result = generate_nutrition_tip("general_fitness")
    assert result["text"]
    assert result["mode"] in {"demo", "gemini"}


def test_html_generate_and_feedback_flow():
    generated = client.post("/generate-workout", data={
        "username": "Web Test", "user_id": "web-test-001", "age": "24",
        "weight": "62", "goal": "muscle_gain", "intensity": "medium",
    })
    assert generated.status_code == 200
    assert "Your plan" in generated.text
    assert "7-day schedule" in generated.text

    revised = client.post("/submit-feedback", data={
        "user_id": "web-test-001",
        "feedback": "Please include more gentle cardio and an extra rest day.",
    })
    assert revised.status_code == 200
    assert "Your plan has been updated based on your feedback." in revised.text
