from typing import Any
from app.config import GOOGLE_API_KEY, GEMINI_PLAN_MODEL, GEMINI_TIP_MODEL

GOAL_LABELS = {
    "weight_loss": "weight loss",
    "muscle_gain": "muscle gain",
    "general_fitness": "general fitness and wellbeing",
    "flexibility": "flexibility and mobility",
    "endurance": "cardiovascular endurance",
}
INTENSITY_LABELS = {"low": "low", "medium": "moderate", "high": "high"}


def _demo_plan(profile: dict[str, Any]) -> str:
    goal = GOAL_LABELS.get(profile["goal"], profile["goal"])
    intensity = INTENSITY_LABELS.get(profile["intensity"], profile["intensity"])
    sessions = [
        ("Day 1 — Full-body foundation", "Chair/bodyweight squats, wall or incline push-ups, glute bridges, bird dogs"),
        ("Day 2 — Cardio and mobility", "Comfortable brisk walk or marching, hip circles, shoulder mobility, gentle stretches"),
        ("Day 3 — Strength and core", "Supported reverse lunges, incline push-ups, dead bugs, calf raises"),
        ("Day 4 — Recovery", "Easy walk, gentle full-body mobility, relaxed breathing"),
        ("Day 5 — Full-body practice", "Sit-to-stands, hip hinges, wall push-ups, bird dogs"),
        ("Day 6 — Cardio and flexibility", "Comfortable walk, step-touch, hamstring and chest stretches"),
        ("Day 7 — Rest and reflection", "Rest or optional gentle mobility; note how the week felt"),
    ]
    lines = [
        "FITBUDDY — 7-DAY STARTER PLAN",
        f"Goal: {goal.title()} | Preferred intensity: {intensity.title()}",
        "",
        "Start conservatively. Warm up for 5–10 minutes before activity and cool down gently.",
        "Choose a version of each movement that feels controlled and pain-free.",
        "",
    ]
    for day, exercises in sessions:
        lines.extend([
            day,
            "Warm-up: 5–10 minutes of easy movement.",
            f"Main session: {exercises}. Begin with 1–3 sets of 8–12 comfortable repetitions, or 10–20 minutes of easy cardio.",
            "Rest: Take 60–120 seconds as needed between strength sets.",
            "Cool-down: 3–5 minutes of easy walking and gentle stretching.",
            "",
        ])
    lines.extend([
        "PROGRESSION",
        "If the session feels manageable and recovery is good, add a few repetitions or a small amount of time next week—not everything at once.",
        "Stop if you feel chest pain, faintness, unusual shortness of breath, or sharp pain. Adapt the plan to your abilities.",
        "",
        "Demo mode note: configure GOOGLE_API_KEY in .env to generate a personalized plan with Gemini.",
    ])
    return "\n".join(lines)


def _demo_tip(goal: str) -> str:
    tips = {
        "weight_loss": "Build meals around vegetables or fruit, a protein source, and high-fibre carbohydrates. Sustainable habits matter more than extreme restriction.",
        "muscle_gain": "Include a protein-rich food in regular meals, eat enough overall to support training, and allow time for recovery and sleep.",
        "general_fitness": "Keep a water bottle nearby, eat varied balanced meals, and aim for a consistent sleep routine to support everyday activity.",
        "flexibility": "Try gentle mobility when your body is warm, move without bouncing, and never force a stretch into pain.",
        "endurance": "Increase cardio time gradually, hydrate regularly, and include easier days so your body can recover.",
    }
    return tips.get(goal, tips["general_fitness"]) + " This is general information, not individualized medical advice."


def _generate(prompt: str, model: str, fallback: str) -> dict[str, str | None]:
    if not GOOGLE_API_KEY:
        return {"text": fallback, "mode": "demo",
                "warning": "Gemini API key not configured. Showing demo-mode content."}
    try:
        from google import genai  # Imported only when live Gemini calls are enabled.
        client = genai.Client(api_key=GOOGLE_API_KEY)
        response = client.models.generate_content(model=model, contents=prompt)
        text = (getattr(response, "text", None) or "").strip()
        if not text:
            raise RuntimeError("Gemini returned an empty response.")
        return {"text": text, "mode": "gemini", "warning": None}
    except Exception as exc:
        return {"text": fallback, "mode": "demo",
                "warning": f"Gemini request failed; showing demo-mode content instead. Details: {str(exc)[:240]}"}


def generate_workout(profile: dict[str, Any]) -> dict[str, str | None]:
    goal = GOAL_LABELS.get(profile["goal"], profile["goal"])
    intensity = INTENSITY_LABELS.get(profile["intensity"], profile["intensity"])
    prompt = f'''
You are a cautious fitness-planning assistant, not a doctor. Create a practical seven-day workout plan.
Profile:
- Name: {profile["username"]}
- Age: {profile["age"]}
- Weight: {profile["weight"]} kg
- Goal: {goal}
- Preferred intensity: {intensity}

Requirements:
- Include all seven days, with a clear focus for each day.
- For each day include warm-up, exercises with sets/reps or duration, rest guidance, and cooldown/recovery.
- Include rest or low-impact recovery days and alternatives for limited equipment.
- Avoid extreme claims, unsafe rapid weight-loss advice, or medical diagnosis.
- Remind the user to stop if they experience pain, dizziness, chest pain, or unusual breathlessness, and to seek professional advice when appropriate.
- Keep the plan clear and scannable in plain text. Do not prescribe a strict diet or claim guaranteed results.
'''
    return _generate(prompt, GEMINI_PLAN_MODEL, _demo_plan(profile))


def generate_nutrition_tip(goal: str) -> dict[str, str | None]:
    goal_label = GOAL_LABELS.get(goal, goal)
    prompt = f'''
Give one concise, practical nutrition or recovery tip for someone whose fitness goal is {goal_label}.
Use supportive, non-judgmental language. Avoid exact medical prescriptions, extreme restriction, supplement claims, or guaranteed outcomes.
Keep it to 2–4 sentences and include a reminder that individual needs vary if relevant.
'''
    return _generate(prompt, GEMINI_TIP_MODEL, _demo_tip(goal))


def update_workout(original_plan: str, feedback: str, profile: dict[str, Any]) -> dict[str, str | None]:
    prompt = f'''
You are a cautious fitness-planning assistant. Revise the workout plan using the user's feedback.
Profile: age {profile["age"]}, weight {profile["weight"]} kg, goal {GOAL_LABELS.get(profile["goal"], profile["goal"])},
preferred intensity {profile["intensity"]}.
Original plan:
{original_plan[:12000]}

User feedback:
{feedback}

Return the complete revised seven-day plan, not just a list of changes. Preserve useful parts that were not requested to change.
Do not follow requests that would make the plan unsafe. Include warm-up, main session, cooldown/recovery, rest days, and a brief safety reminder.
'''
    fallback = (
        _demo_plan(profile)
        + "\n\nFEEDBACK RECEIVED\n"
        + f"Your requested change was: {feedback}\n"
        + "Demo mode cannot fully rewrite the plan with AI. Review the request and adjust the starter plan conservatively. "
          "Configure GOOGLE_API_KEY to enable Gemini-based revisions."
    )
    return _generate(prompt, GEMINI_PLAN_MODEL, fallback)
