from typing import Literal
from pydantic import BaseModel, Field, ConfigDict

FitnessGoal = Literal["weight_loss", "muscle_gain", "general_fitness", "flexibility", "endurance"]
Intensity = Literal["low", "medium", "high"]


class UserInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    username: str = Field(min_length=1, max_length=100)
    user_id: str = Field(min_length=1, max_length=80, pattern=r"^[A-Za-z0-9_.-]+$")
    age: int = Field(ge=13, le=100)
    weight: float = Field(gt=20, le=350)
    goal: FitnessGoal
    intensity: Intensity


class FeedbackRequest(BaseModel):
    feedback: str = Field(min_length=3, max_length=1500)


class PlanResponse(BaseModel):
    message: str
    user_id: str
    workout_plan: str
    nutrition_tip: str
    mode: str
    warning: str | None = None
