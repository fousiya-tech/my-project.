import secrets
from typing import Annotated
from fastapi import APIRouter, Depends, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.templating import Jinja2Templates
from pydantic import ValidationError
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai_service import generate_nutrition_tip, generate_workout, update_workout
from app.config import ADMIN_PASSWORD, ADMIN_USERNAME
from app.database import get_db
from app.models import User, WorkoutPlan
from app.schemas import FeedbackRequest, PlanResponse, UserInput

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")
security = HTTPBasic()


def require_admin(credentials: Annotated[HTTPBasicCredentials, Depends(security)]) -> str:
    user_ok = secrets.compare_digest(credentials.username, ADMIN_USERNAME)
    password_ok = secrets.compare_digest(credentials.password, ADMIN_PASSWORD)
    if not (user_ok and password_ok):
        raise HTTPException(status_code=401, detail="Invalid admin credentials",
                            headers={"WWW-Authenticate": "Basic"})
    return credentials.username


def _profile(user: User) -> dict:
    return {"username": user.username, "user_id": user.user_id, "age": user.age,
            "weight": user.weight, "goal": user.goal, "intensity": user.intensity}


def _upsert_user(db: Session, data: UserInput) -> User:
    user = db.scalar(select(User).where(User.user_id == data.user_id))
    if user is None:
        user = User(user_id=data.user_id, username=data.username, age=data.age, weight=data.weight,
                    goal=data.goal, intensity=data.intensity)
        db.add(user)
    else:
        user.username, user.age, user.weight = data.username, data.age, data.weight
        user.goal, user.intensity = data.goal, data.intensity
    db.flush()
    return user


def _upsert_plan(db: Session, user_id: str, original: str, tip: str,
                 updated: str | None = None, feedback: str | None = None) -> WorkoutPlan:
    plan = db.scalar(select(WorkoutPlan).where(WorkoutPlan.user_id == user_id))
    if plan is None:
        plan = WorkoutPlan(user_id=user_id, original_plan=original, updated_plan=updated,
                           nutrition_tip=tip, last_feedback=feedback)
        db.add(plan)
    else:
        plan.original_plan, plan.updated_plan = original, updated
        plan.nutrition_tip, plan.last_feedback = tip, feedback
    db.flush()
    return plan


def _result_context(request: Request, user: User, plan: WorkoutPlan, mode: str,
                    warning: str | None, message: str | None = None) -> dict:
    return {"request": request, "user": user, "plan": plan, "mode": mode, "warning": warning,
            "message": message, "active_plan": plan.updated_plan or plan.original_plan}


@router.get("/", response_class=HTMLResponse, name="home")
def home(request: Request):
    return templates.TemplateResponse(request, "index.html", {"error": None})


@router.post("/generate-workout", response_class=HTMLResponse)
def generate_workout_page(
    request: Request,
    username: Annotated[str, Form()],
    user_id: Annotated[str, Form()],
    age: Annotated[int, Form()],
    weight: Annotated[float, Form()],
    goal: Annotated[str, Form()],
    intensity: Annotated[str, Form()],
    db: Session = Depends(get_db),
):
    try:
        data = UserInput(username=username, user_id=user_id, age=age, weight=weight,
                         goal=goal, intensity=intensity)
    except ValidationError as exc:
        message = "; ".join(f"{'.'.join(str(p) for p in e['loc'])}: {e['msg']}" for e in exc.errors())
        return templates.TemplateResponse(request, "index.html", {"error": message}, status_code=422)

    user = _upsert_user(db, data)
    workout = generate_workout(data.model_dump())
    tip = generate_nutrition_tip(data.goal)
    _upsert_plan(db, user.user_id, str(workout["text"]), str(tip["text"]))
    db.commit()
    db.refresh(user)
    db.refresh(user.plan)
    warning = " ".join(x for x in (workout.get("warning"), tip.get("warning")) if x) or None
    return templates.TemplateResponse(request, "result.html", _result_context(
        request, user, user.plan, str(workout["mode"]), warning
    ))


@router.post("/submit-feedback", response_class=HTMLResponse)
def submit_feedback_page(
    request: Request,
    user_id: Annotated[str, Form()],
    feedback: Annotated[str, Form()],
    db: Session = Depends(get_db),
):
    try:
        clean_feedback = FeedbackRequest(feedback=feedback).feedback
    except ValidationError:
        raise HTTPException(status_code=422, detail="Feedback must contain 3–1500 characters.")
    user = db.scalar(select(User).where(User.user_id == user_id))
    if user is None or user.plan is None:
        raise HTTPException(status_code=404, detail="No plan found for that user ID. Generate a plan first.")
    original = user.plan.updated_plan or user.plan.original_plan
    result = update_workout(original, clean_feedback, _profile(user))
    user.plan.updated_plan = str(result["text"])
    user.plan.last_feedback = clean_feedback
    db.commit()
    db.refresh(user.plan)
    return templates.TemplateResponse(request, "result.html", _result_context(
        request, user, user.plan, str(result["mode"]), result.get("warning"),
        "Your plan has been updated based on your feedback."
    ))


@router.get("/view-all-users", response_class=HTMLResponse)
def view_all_users(request: Request, _: Annotated[str, Depends(require_admin)],
                   db: Session = Depends(get_db)):
    users = db.scalars(select(User).order_by(User.id.desc())).all()
    return templates.TemplateResponse(request, "all_users.html", {"users": users})


@router.post("/admin/delete-user")
def delete_user_page(user_id: Annotated[str, Form()], _: Annotated[str, Depends(require_admin)],
                     db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.user_id == user_id))
    if user:
        db.delete(user)
        db.commit()
    return RedirectResponse(url="/view-all-users", status_code=303)


@router.get("/health")
def health():
    return {"status": "ok", "service": "FitBuddy"}


@router.post("/api/plans", response_model=PlanResponse)
def api_generate_plan(data: UserInput, db: Session = Depends(get_db)):
    user = _upsert_user(db, data)
    workout = generate_workout(data.model_dump())
    tip = generate_nutrition_tip(data.goal)
    _upsert_plan(db, user.user_id, str(workout["text"]), str(tip["text"]))
    db.commit()
    return PlanResponse(
        message="Workout plan generated and saved.", user_id=user.user_id,
        workout_plan=str(workout["text"]), nutrition_tip=str(tip["text"]),
        mode=str(workout["mode"]),
        warning=" ".join(x for x in (workout.get("warning"), tip.get("warning")) if x) or None,
    )


@router.post("/api/plans/{user_id}/feedback")
def api_submit_feedback(user_id: str, data: FeedbackRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.user_id == user_id))
    if user is None or user.plan is None:
        raise HTTPException(status_code=404, detail="No plan found for that user ID. Generate a plan first.")
    result = update_workout(user.plan.updated_plan or user.plan.original_plan, data.feedback, _profile(user))
    user.plan.updated_plan, user.plan.last_feedback = str(result["text"]), data.feedback
    db.commit()
    return {"message": "Workout plan updated.", "user_id": user_id,
            "updated_plan": str(result["text"]), "mode": result["mode"], "warning": result.get("warning")}


@router.get("/api/nutrition-tip")
def api_nutrition_tip(goal: str = "general_fitness"):
    if goal not in {"weight_loss", "muscle_gain", "general_fitness", "flexibility", "endurance"}:
        raise HTTPException(status_code=422, detail="Unsupported fitness goal.")
    result = generate_nutrition_tip(goal)
    return {"goal": goal, "nutrition_tip": result["text"], "mode": result["mode"], "warning": result["warning"]}


@router.get("/api/admin/users")
def api_admin_users(_: Annotated[str, Depends(require_admin)], db: Session = Depends(get_db)):
    users = db.scalars(select(User).order_by(User.id.desc())).all()
    return [
        {"user_id": user.user_id, "username": user.username, "age": user.age, "weight": user.weight,
         "goal": user.goal, "intensity": user.intensity,
         "original_plan": user.plan.original_plan if user.plan else None,
         "updated_plan": user.plan.updated_plan if user.plan else None,
         "nutrition_tip": user.plan.nutrition_tip if user.plan else None}
        for user in users
    ]


@router.delete("/api/admin/users/{user_id}", status_code=204)
def api_delete_user(user_id: str, _: Annotated[str, Depends(require_admin)], db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.user_id == user_id))
    if user is None:
        raise HTTPException(status_code=404, detail="User not found.")
    db.delete(user)
    db.commit()
    return None
